getal1 = float(input('geef me een cijfer #1 '))
getal2 = float(input('geef me een cijfer #2 '))
getal3 = float(input('geef me een cijfer #3 '))
result = (getal1 + getal2 + getal3) / 3
print(f'De gemiddelde van de 3 cijfers is {result}')