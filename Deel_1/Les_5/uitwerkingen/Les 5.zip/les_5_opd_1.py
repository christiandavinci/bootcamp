getal = (int('252'))

print (f'hallo {getal}, ik leer nu programmeren')