Leeftijd = 16

if Leeftijd >= 16:
    print("gefelicteerd, je mag je brommerrijbenwijs halen.")
else:
    print("Helaas, je zult nog even  moeten wachten")