a = 3
b = 7
if a > b:
     print(f"varaibele a is het grootste want {a} is groter dan {b}")
elif b > a: 
     print(f"varaibele b is het grootst want {b} is groter dan {a}")  
else:
     print("varaibele a en b zijn gelijk.")     


