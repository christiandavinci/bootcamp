if x == 18:
    print('de waarde van x = 18')