resultaat = 0

getal = 12

doelgetal = 625

while doelgetal >= getal:
    doelgetal -= getal
    resultaat += 1

print(f"{getal} past {resultaat} keer in {doelgetal}.")


