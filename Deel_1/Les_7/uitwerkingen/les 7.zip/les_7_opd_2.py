count = 0

while count < 20:
    print(" ik ben hard onderweg om develpor te worden")
    count += 1 