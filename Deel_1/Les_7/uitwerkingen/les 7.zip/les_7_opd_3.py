resultaat = 0

getal = 25

doelgetal = 625

while doelgetal >= getal:
    doelgetal -= getal
    resultaat += 1

print("25 past", resultaat, "keer in 625.")