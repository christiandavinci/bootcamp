x = 1
while x <= 25:
     print(x)
     x+=1