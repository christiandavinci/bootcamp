cijfer = int(input("wat is jou cijfer: "))

if cijfer == 10:
    print("Uitmuntend")
elif cijfer == 9:
    print("Zeer goed")
elif cijfer == 8:
    print("Goed")
elif cijfer == 7:
    print("Ruim voldoende")
elif cijfer == 6:
    print("Voldoende")
elif cijfer == 5:
    print("Bijna voldoende")
elif cijfer == 4:
    print("Onvoldoende")
elif cijfer == 3:
    print("Gering")
elif cijfer == 2:
    print("Slecht")
elif cijfer == 1:
    print("Zeer slecht")
else:
    print("Dit kan ik niet omzetten!")
