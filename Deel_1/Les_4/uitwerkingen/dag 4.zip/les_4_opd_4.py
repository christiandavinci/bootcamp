naam= "Christian" 
print("hallo" + 252 + ", ik leer nu programmeren")
# het programma werkt nog steeds 