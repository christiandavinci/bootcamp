aantal_keer = 625 // 13 # bereken dat 13 in 625 past
overblijvend = 625 % 13 # bereken wat er overblijft
print("het past", aantal_keer, "keer in 625, met ", overblijvend, "over.")
