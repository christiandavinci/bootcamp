variable_een = 25
variable_twee = 0
resutaalt = variable_een / variable_twee
print(resutaalt)
# dit zorgt er voor voor een zerodivisioerror omdat je door nul deelt en dat kan niet