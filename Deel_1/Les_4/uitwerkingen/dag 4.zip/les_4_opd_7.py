print( (431 /100) *100)
# het anwoord is 431 omdat je hem eerst deelt en daara weer keer doet en omdat het een decimaal antwoordt krijgt wordt het afgerond 431