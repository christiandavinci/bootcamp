print(5*2 -3+4/2) # uitkomst:9.0 (volgt de volgorde van wiskundige bewerkingen )
print(5*2 - 3+4 /2) # uitkomst: 9.0 (volgt dezelfde volgorde van wiskundige bewerkingen ) 
print((5*2) - (3+4) /2) # uitkomst 6.5 (eerstbinnen de haakjes, dan deling en daarna aftrekking)
print(((5*2) -(3+4)) / 2) # uitkomst 2.0 (eerst binnen de haakjes, dan aftrekking, en daarna deling )