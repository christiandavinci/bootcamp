naam = "christian" 
print("hallo" + naam + ", ik leer nu programmeren")
# operators gebruikt: + om teskt te conacten
# je kan de naam veranderen en dan blijft hij werken