seconden_per_minuut = 60
minuten_per_uur = 60
uren_per_dag = 24
dagen_per_week = 7
dagen_per_jaar = 365


seconden_in_dag = seconden_per_minuut * minuten_per_uur * uren_per_dag
seconden_in_week = seconden_in_dag * dagen_per_week
seconden_in_jaar = seconden_in_dag * dagen_per_jaar

print("seconden in een dag:", seconden_in_dag)
print("seconden in een week:", seconden_in_week)
print("seconden in jaar", seconden_in_jaar)