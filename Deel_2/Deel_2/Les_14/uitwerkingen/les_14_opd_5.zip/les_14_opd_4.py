mijn_lijst = []

for getal  in range (5):
    item = input ("welke getal wilt u toevogen?")
    mijn_lijst.append(item)
for getal in mijn_lijst:
    print(getal + "\n")


# # Opdracht 4:
# # schrijf een programma dat een lege lijst maakt en vervolgens de gebruiker vraagt om 5 
# # woorden in te voeren. Gebruik de append functie om elk woord aan de lijst toe te voegen 
# # en gebruik vervolgens een for-lus om door elk woord in de lijst te itereren en print 
# # elk woord op een aparte regel.

# my_list = []

# words = input("Enter 5 words: ")

# words = words.split(', ')
# for word in words:
#     my_list.append(word)
    
# for word in my_list:
#     print(word)


