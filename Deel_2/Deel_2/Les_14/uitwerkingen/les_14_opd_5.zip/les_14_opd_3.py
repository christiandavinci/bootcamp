mijn_lijst = ['appel', 'citroen', 'druif', 'peer', 'perzik']


item = input ("welke fruit wilt u verwijderen?")
mijn_lijst.remove(item)
print('de lijst is:',mijn_lijst)





# Opdracht 3:
# Schrijf een programma dat een lijst van fruitsoorten maakt en vervolgens de gebruiker 
# vraagt om een fruitsoort in te voeren. Gebruik de remove functie om het opgegeven 
# fruit uit de lijst te verwijderen en print vervolgens de bijgewerkte lijst.
