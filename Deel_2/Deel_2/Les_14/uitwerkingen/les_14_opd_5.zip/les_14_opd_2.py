mijn_lijst = [3,12,27,5,9]
index =  int(input('welk index getal wilt u?') )

verwijder_getal = mijn_lijst[index]

mijn_lijst.pop(index)
print  (verwijder_getal)
print  (mijn_lijst)






# Opdracht 2:
# Schrijf een programma dat een lijst van 5 getallen maakt en vervolgens de gebruiker vraagt om een index in te voeren. 
# Gebruik de pop functie om het getal op de opgegeven index uit de lijst te verwijderen 
# en print vervolgens het verwijderde getal en de bijgewerkte lijst.