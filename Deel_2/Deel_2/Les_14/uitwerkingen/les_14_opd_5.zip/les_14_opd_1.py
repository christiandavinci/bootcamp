mijn_lijst = []

for getal  in range (5):
    item = input ("welke getal wilt u toevogen?")
    mijn_lijst.append(item)
    print('de lijst is:',mijn_lijst)
    
















# boodschappen = ()


# Opdracht 1: 
# om 5 getallen in te voeren. Gebruik de append functie om elk getal aan de lijst Schrijf
# een programma dat een lege lijst maakt en vervolgens de gebruiker vraagttoe te voegen en print vervolgens de lijst.